import { apiRequest } from "./queryClient";
import type { 
  RobloxUser, 
  RobloxUserStatus 
} from "@shared/schema";

export interface UserResponse {
  source: "cache" | "api";
  data: RobloxUser;
  avatarUrl: string | null;
  isTerminated: boolean;
  previousUsernames?: string[];
  stats?: {
    friends: number;
    followers: number;
    following: number;
  };
}

interface UserStats {
  friends: number | string;
  followers: number | string;
  following: number | string;
}

// Get user by ID (can be terminated account)
export async function fetchUserById(userId: string): Promise<UserResponse> {
  const response = await fetch(`/api/users/${userId}`, {
    credentials: "include",
  });
  
  if (!response.ok) {
    throw new Error(`Failed to fetch user: ${response.statusText}`);
  }
  
  return await response.json();
}

// Convert username to user ID
export async function getUserIdByUsername(username: string): Promise<string> {
  const response = await apiRequest("POST", "/api/users/by-username", { username });
  const data = await response.json();
  return data.userId;
}

// Get user status
export async function getUserStatus(userId: string): Promise<RobloxUserStatus> {
  const response = await fetch(`/api/users/${userId}/status`, {
    credentials: "include",
  });
  
  if (!response.ok) {
    return { status: "" };
  }
  
  return await response.json();
}

// Get user stats
export async function getUserStats(userId: string): Promise<UserStats> {
  const response = await fetch(`/api/users/${userId}/stats`, {
    credentials: "include",
  });
  
  if (!response.ok) {
    return {
      friends: "N/A",
      followers: "N/A",
      following: "N/A"
    };
  }
  
  return await response.json();
}

// Get recent searches
export async function getRecentSearches(limit: number = 10): Promise<any[]> {
  const response = await fetch(`/api/search-history?limit=${limit}`, {
    credentials: "include",
  });
  
  if (!response.ok) {
    return [];
  }
  
  return await response.json();
}

// Calculate account age in years and days
export function calculateAccountAge(createdDate: string): string {
  if (!createdDate) return "Unknown";
  
  const created = new Date(createdDate);
  const now = new Date();
  
  const diffTime = Math.abs(now.getTime() - created.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  const years = Math.floor(diffDays / 365);
  const days = diffDays % 365;
  
  if (years > 0) {
    return `${years} year${years !== 1 ? 's' : ''}, ${days} day${days !== 1 ? 's' : ''}`;
  }
  
  return `${days} day${days !== 1 ? 's' : ''}`;
}

// Format join date
export function formatJoinDate(createdDate: string): string {
  if (!createdDate) return "Unknown";
  
  const date = new Date(createdDate);
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
}
