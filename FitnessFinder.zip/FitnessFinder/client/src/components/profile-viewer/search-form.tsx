import { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { getUserIdByUsername } from "@/lib/roblox-api";
import { useToast } from "@/hooks/use-toast";
import { Search, Loader2 } from "lucide-react";

const searchSchema = z.object({
  query: z.string().min(1, "Search query is required"),
  type: z.enum(["username", "userid"])
});

type SearchFormValues = z.infer<typeof searchSchema>;

export default function SearchForm() {
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const form = useForm<SearchFormValues>({
    resolver: zodResolver(searchSchema),
    defaultValues: {
      query: "",
      type: "username"
    }
  });
  
  async function onSubmit(data: SearchFormValues) {
    setIsLoading(true);
    
    try {
      if (data.type === "userid") {
        // Validate that it's a number
        if (!/^\d+$/.test(data.query)) {
          toast({
            title: "Invalid User ID",
            description: "User ID must be a number",
            variant: "destructive"
          });
          return;
        }
        
        // Go directly to profile page with user ID
        setLocation(`/profile/${data.query}`);
      } else {
        // Convert username to ID first
        try {
          const userId = await getUserIdByUsername(data.query);
          setLocation(`/profile/${userId}`);
        } catch (error) {
          toast({
            title: "User Not Found",
            description: "Could not find a user with that username",
            variant: "destructive"
          });
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred during search",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }
  
  return (
    <Card className="w-full max-w-2xl mx-auto shadow-md mb-6">
      <CardHeader>
        <CardTitle className="text-xl font-bold">Roblox Profile Viewer</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-row space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="username" id="username" />
                        <Label htmlFor="username">Username</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="userid" id="userid" />
                        <Label htmlFor="userid">User ID</Label>
                      </div>
                    </RadioGroup>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="flex space-x-2">
              <FormField
                control={form.control}
                name="query"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormControl>
                      <Input 
                        placeholder={form.watch("type") === "username" ? "Enter username..." : "Enter user ID..."} 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                Search
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
