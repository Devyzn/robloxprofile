import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Ban, CheckCircle2, AlertTriangle } from "lucide-react";

interface ProfileStatusBadgeProps {
  isTerminated: boolean;
}

export default function ProfileStatusBadge({ isTerminated }: ProfileStatusBadgeProps) {
  if (isTerminated) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge variant="destructive" className="ml-2 font-semibold">
              <Ban className="h-3 w-3 mr-1" />
              Terminated
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p>This account has been terminated for violating Roblox Terms of Service</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="success" className="ml-2 bg-green-600 text-white">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Active
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>This account is active</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
