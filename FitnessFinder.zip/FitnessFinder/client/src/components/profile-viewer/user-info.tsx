import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import ProfileStatusBadge from "./profile-status-badge";
import { ScrollArea } from "@/components/ui/scroll-area";

interface UserInfoProps {
  displayName: string;
  username: string;
  status: string;
  description: string;
  isTerminated: boolean;
}

export default function UserInfo({ 
  displayName, 
  username, 
  status, 
  description, 
  isTerminated 
}: UserInfoProps) {
  return (
    <Card className="shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center">
              {displayName || username}
              <ProfileStatusBadge isTerminated={isTerminated} />
            </h1>
            <p className="text-gray-500 dark:text-gray-400">@{username}</p>
          </div>
        </div>
        
        {status && (
          <div className="mt-2">
            <p className="text-sm italic text-gray-600 dark:text-gray-300">{status}</p>
          </div>
        )}
        
        <Separator className="my-3" />
        
        <div className="mt-2">
          <h2 className="text-sm font-semibold mb-1">About</h2>
          <ScrollArea className="h-[100px] w-full rounded-md border p-2">
            <p className="text-sm whitespace-pre-wrap">
              {description || "No description available."}
            </p>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  );
}
