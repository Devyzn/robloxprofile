import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Ban } from "lucide-react";

interface UserAvatarProps {
  avatarUrl: string | null;
  username: string;
  isTerminated: boolean;
  size?: "sm" | "md" | "lg" | "xl";
}

export default function UserAvatar({ 
  avatarUrl, 
  username, 
  isTerminated,
  size = "md" 
}: UserAvatarProps) {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };
  
  const sizeClasses = {
    sm: "h-12 w-12",
    md: "h-24 w-24",
    lg: "h-32 w-32",
    xl: "h-40 w-40"
  };
  
  const fallbackSizes = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-3xl",
    xl: "text-4xl"
  };
  
  return (
    <Avatar className={`${sizeClasses[size]} ${isTerminated ? 'ring-2 ring-red-500' : ''}`}>
      {avatarUrl ? (
        <AvatarImage src={avatarUrl} alt={username} />
      ) : (
        <></>
      )}
      <AvatarFallback className={`${fallbackSizes[size]} ${isTerminated ? 'bg-red-100 text-red-800' : 'bg-primary/10'}`}>
        {isTerminated ? <Ban className="h-6 w-6" /> : getInitials(username)}
      </AvatarFallback>
    </Avatar>
  );
}
