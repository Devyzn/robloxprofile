import { useEffect, useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowLeft, AlertTriangle } from "lucide-react";
import UserAvatar from "./user-avatar";
import UserInfo from "./user-info";
import UserStats from "./user-stats";
import UserDetails from "./user-details";
import PreviousUsernames from "./previous-usernames";
import { fetchUserById, getUserStatus, getUserStats } from "@/lib/roblox-api";
import type { RobloxUser } from "@shared/schema";

export default function ProfilePage() {
  const [, params] = useRoute("/profile/:userId");
  const userId = params?.userId || "";
  
  // Fetch user data
  const { data, isLoading: isUserLoading, error: userError } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });
  
  // Fetch user status
  const [status, setStatus] = useState("");
  const [isStatusLoading, setIsStatusLoading] = useState(false);
  
  // Fetch stats (friends, followers, following)
  const [localStats, setLocalStats] = useState({
    friends: "N/A",
    followers: "N/A",
    following: "N/A"
  });
  const [isStatsLoading, setIsStatsLoading] = useState(false);
  
  useEffect(() => {
    if (!userId) return;
    
    async function fetchAdditionalData() {
      try {
        // Fetch status
        setIsStatusLoading(true);
        try {
          const statusData = await getUserStatus(userId);
          setStatus(statusData.status || "");
        } catch (e) {
          console.error("Failed to fetch status", e);
        } finally {
          setIsStatusLoading(false);
        }
        
        // Fetch stats
        setIsStatsLoading(true);
        try {
          const statsData = await getUserStats(userId);
          setLocalStats(statsData);
        } catch (e) {
          console.error("Failed to fetch stats", e);
        } finally {
          setIsStatsLoading(false);
        }
      } catch (error: any) {
        console.error("Failed to load profile data", error);
      }
    }
    
    fetchAdditionalData();
  }, [userId]);
  
  if (!userId) {
    return (
      <div className="container max-w-5xl mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>User ID is required</AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link to="/">Go back to search</Link>
        </Button>
      </div>
    );
  }
  
  if (userError) {
    return (
      <div className="container max-w-5xl mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error loading profile</AlertTitle>
          <AlertDescription>
            {userError instanceof Error ? userError.message : "An unknown error occurred"}
          </AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link to="/">Go back to search</Link>
        </Button>
      </div>
    );
  }
  
  if (!data) {
    return (
      <div className="container max-w-5xl mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>Failed to load user data</AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link to="/">Go back to search</Link>
        </Button>
      </div>
    );
  }
  
  const userData = data;
  const user = userData.data as RobloxUser;
  const isTerminated = userData.isTerminated || false;
  const avatarUrl = userData.avatarUrl;
  const previousUsernames = userData.previousUsernames || [];
  
  // Use stats from API response if available
  const userStats = {
    friends: userData.stats?.friends !== undefined ? userData.stats.friends : stats.friends,
    followers: userData.stats?.followers !== undefined ? userData.stats.followers : stats.followers,
    following: userData.stats?.following !== undefined ? userData.stats.following : stats.following
  };
  
  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <Button asChild variant="outline" className="mb-6">
        <Link to="/">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Search
        </Link>
      </Button>
      
      {isUserLoading ? (
        <ProfileSkeleton />
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="flex flex-col items-center md:items-start space-y-2">
              <UserAvatar 
                avatarUrl={avatarUrl} 
                username={user.name} 
                isTerminated={isTerminated}
                size="xl"
              />
            </div>
            
            <div className="md:col-span-3 space-y-4">
              <UserInfo 
                displayName={user.displayName || user.name} 
                username={user.name}
                status={isStatusLoading ? "Loading status..." : status}
                description={user.description || ""}
                isTerminated={isTerminated}
              />
              
              {previousUsernames && previousUsernames.length > 0 && (
                <PreviousUsernames previousUsernames={previousUsernames} />
              )}
              
              <UserStats 
                friends={userStats.friends}
                followers={userStats.followers}
                following={userStats.following}
                joinDate={user.created}
              />
            </div>
          </div>
          
          <UserDetails 
            userId={userId} 
            isTerminated={isTerminated}
          />
        </div>
      )}
    </div>
  );
}

function ProfileSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex flex-col items-center md:items-start space-y-2">
          <Skeleton className="h-40 w-40 rounded-full" />
        </div>
        
        <div className="md:col-span-3 space-y-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
      
      <Skeleton className="h-60 w-full" />
    </div>
  );
}