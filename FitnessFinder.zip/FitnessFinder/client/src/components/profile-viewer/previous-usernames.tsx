import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { History } from "lucide-react";

interface PreviousUsernamesProps {
  previousUsernames: string[];
}

export default function PreviousUsernames({ previousUsernames }: PreviousUsernamesProps) {
  if (!previousUsernames || previousUsernames.length === 0) {
    return null;
  }

  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center">
          <History className="h-4 w-4 mr-2 text-primary" />
          Previous Usernames
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {previousUsernames.map((username, index) => (
            <Badge key={index} variant="outline">
              {username}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}