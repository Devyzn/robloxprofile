import { Card, CardContent } from "@/components/ui/card";
import { CalendarDays, Users, UserCheck, UserPlus } from "lucide-react";
import { formatJoinDate, calculateAccountAge } from "@/lib/roblox-api";

interface UserStatsProps {
  friends: number | string;
  followers: number | string;
  following: number | string;
  joinDate?: string;
  isPremium?: boolean;
}

export default function UserStats({ 
  friends, 
  followers, 
  following,
  joinDate,
  isPremium
}: UserStatsProps) {
  const formattedDate = joinDate ? formatJoinDate(joinDate) : 'Unknown';
  const accountAge = joinDate ? calculateAccountAge(joinDate) : 'Unknown';
  
  return (
    <Card className="shadow-sm">
      <CardContent className="p-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="flex flex-col items-center p-2 rounded-lg bg-background/50">
            <div className="flex items-center mb-1">
              <Users className="h-4 w-4 mr-1 text-primary" />
              <span className="text-xs font-medium">Friends</span>
            </div>
            <span className="text-xl font-bold">{friends}</span>
          </div>
          
          <div className="flex flex-col items-center p-2 rounded-lg bg-background/50">
            <div className="flex items-center mb-1">
              <UserPlus className="h-4 w-4 mr-1 text-primary" />
              <span className="text-xs font-medium">Followers</span>
            </div>
            <span className="text-xl font-bold">{followers}</span>
          </div>
          
          <div className="flex flex-col items-center p-2 rounded-lg bg-background/50">
            <div className="flex items-center mb-1">
              <UserCheck className="h-4 w-4 mr-1 text-primary" />
              <span className="text-xs font-medium">Following</span>
            </div>
            <span className="text-xl font-bold">{following}</span>
          </div>
          
          {joinDate && (
            <div className="flex flex-col items-center p-2 rounded-lg bg-background/50">
              <div className="flex items-center mb-1">
                <CalendarDays className="h-4 w-4 mr-1 text-primary" />
                <span className="text-xs font-medium">Joined</span>
              </div>
              <span className="text-xs font-medium text-center">{formattedDate}</span>
              <span className="text-xs text-muted-foreground">{accountAge}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
