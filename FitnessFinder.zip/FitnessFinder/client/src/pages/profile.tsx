import { useEffect, useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowLeft, Loader2, AlertTriangle } from "lucide-react";
import UserAvatar from "@/components/profile-viewer/user-avatar";
import UserInfo from "@/components/profile-viewer/user-info";
import UserStats from "@/components/profile-viewer/user-stats";
import UserDetails from "@/components/profile-viewer/user-details";
import PreviousUsernames from "@/components/profile-viewer/previous-usernames";
import { fetchUserById, getUserStatus, getUserStats } from "@/lib/roblox-api";
import type { RobloxUser, UserResponse } from "@/lib/roblox-api";

export default function ProfilePage() {
  const [, params] = useRoute("/profile/:userId");
  const userId = params?.userId || "";
  
  interface UserDataResponse {
    source?: string;
    data?: RobloxUser;
    avatarUrl?: string | null;
    isTerminated?: boolean;
    previousUsernames?: string[];
    stats?: {
      friends: number;
      followers: number;
      following: number;
    };
  }
  
  const { data: userData = {
    source: "",
    data: undefined,
    avatarUrl: null,
    isTerminated: false,
    previousUsernames: [],
    stats: {
      friends: 0,
      followers: 0,
      following: 0
    }
  } as UserDataResponse, isLoading: isUserLoading, error: userError } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });
  
  // Fetch user status
  const [status, setStatus] = useState("");
  const [isStatusLoading, setIsStatusLoading] = useState(false);
  
  // Fetch stats (friends, followers, following)
  interface ProfileStats {
    friends: string | number;
    followers: string | number;
    following: string | number;
  }
  
  const [stats, setStats] = useState<ProfileStats>({
    friends: "N/A",
    followers: "N/A",
    following: "N/A"
  });
  const [isStatsLoading, setIsStatsLoading] = useState(false);
  
  // Error state
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;
    
    async function fetchAdditionalData() {
      try {
        // Fetch status
        setIsStatusLoading(true);
        try {
          const statusData = await getUserStatus(userId);
          setStatus(statusData.status || "");
        } catch (e) {
          console.error("Failed to fetch status", e);
        } finally {
          setIsStatusLoading(false);
        }
        
        // Fetch stats
        setIsStatsLoading(true);
        try {
          const statsData = await getUserStats(userId);
          setStats(statsData);
        } catch (e) {
          console.error("Failed to fetch stats", e);
        } finally {
          setIsStatsLoading(false);
        }
      } catch (error: any) {
        setError(error.message || "Failed to load profile data");
      }
    }
    
    fetchAdditionalData();
  }, [userId]);
  
  if (!userId) {
    return (
      <div className="container max-w-5xl mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>User ID is required</AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link to="/">Go back to search</Link>
        </Button>
      </div>
    );
  }
  
  if (userError) {
    return (
      <div className="container max-w-5xl mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error loading profile</AlertTitle>
          <AlertDescription>
            {userError instanceof Error ? userError.message : "An unknown error occurred"}
          </AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link to="/">Go back to search</Link>
        </Button>
      </div>
    );
  }
  
  const user = userData.data as RobloxUser | undefined;
  const isTerminated = userData.isTerminated || false;
  const previousUsernames = userData.previousUsernames || (user?.previousUsernames || []);
  
  // Use stats from the response or from the user data if available
  const userStats: ProfileStats = {
    friends: userData.stats?.friends !== undefined ? userData.stats.friends : 
             (user?.stats?.friends !== undefined ? user.stats.friends : stats.friends),
    followers: userData.stats?.followers !== undefined ? userData.stats.followers : 
              (user?.stats?.followers !== undefined ? user.stats.followers : stats.followers),
    following: userData.stats?.following !== undefined ? userData.stats.following : 
              (user?.stats?.following !== undefined ? user.stats.following : stats.following)
  };
  
  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <Button asChild variant="outline" className="mb-6">
        <Link to="/">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Search
        </Link>
      </Button>
      
      {isUserLoading ? (
        <ProfileSkeleton />
      ) : user ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="flex flex-col items-center md:items-start space-y-2">
              <UserAvatar 
                avatarUrl={userData?.avatarUrl || null} 
                username={user.name} 
                isTerminated={isTerminated}
                size="xl"
              />
            </div>
            
            <div className="md:col-span-3 space-y-4">
              <UserInfo 
                displayName={user.displayName || user.name} 
                username={user.name}
                status={isStatusLoading ? "Loading status..." : status}
                description={user.description || ""}
                isTerminated={isTerminated}
              />
              
              {previousUsernames.length > 0 && (
                <PreviousUsernames previousUsernames={previousUsernames} />
              )}
              
              <UserStats 
                friends={userStats.friends}
                followers={userStats.followers}
                following={userStats.following}
                joinDate={user.created}
              />
            </div>
          </div>
          
          <UserDetails 
            userId={userId} 
            isTerminated={isTerminated}
          />
        </div>
      ) : (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>Failed to load user data</AlertDescription>
        </Alert>
      )}
    </div>
  );
}

function ProfileSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex flex-col items-center md:items-start space-y-2">
          <Skeleton className="h-40 w-40 rounded-full" />
        </div>
        
        <div className="md:col-span-3 space-y-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
      
      <Skeleton className="h-60 w-full" />
    </div>
  );
}
