import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import SearchForm from "@/components/profile-viewer/search-form";
import { getRecentSearches } from "@/lib/roblox-api";
import { SearchIcon, Clock, User, AlertTriangle } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Home() {
  const [recentSearches, setRecentSearches] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    async function fetchRecentSearches() {
      setIsLoading(true);
      try {
        const searches = await getRecentSearches(5);
        setRecentSearches(searches);
      } catch (error) {
        console.error("Failed to fetch recent searches", error);
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchRecentSearches();
  }, []);
  
  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <div className="flex justify-end mb-2">
        <ThemeToggle />
      </div>
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold">Roblox Profile Viewer</h1>
        <p className="text-muted-foreground mt-2">
          View any Roblox profile, including terminated accounts
        </p>
      </div>
      
      <SearchForm />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="h-5 w-5 mr-2" />
              Recent Searches
            </CardTitle>
            <CardDescription>Your recent profile lookups</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-4">
                <p>Loading recent searches...</p>
              </div>
            ) : recentSearches.length > 0 ? (
              <ul className="space-y-2">
                {recentSearches.map((search, index) => (
                  <li key={index}>
                    <Link to={`/profile/${search.query}`} className="group">
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start text-left"
                      >
                        <User className="h-4 w-4 mr-2" />
                        <span>{search.query}</span>
                        <span className="ml-auto text-xs text-muted-foreground">
                          {new Date(search.timestamp).toLocaleDateString()}
                        </span>
                      </Button>
                    </Link>
                    {index < recentSearches.length - 1 && <Separator />}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-center py-4 text-muted-foreground">
                <SearchIcon className="h-8 w-8 mx-auto mb-2" />
                <p>No recent searches</p>
                <p className="text-sm">Start by searching for a Roblox user</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2" />
              About Terminated Accounts
            </CardTitle>
            <CardDescription>Important information</CardDescription>
          </CardHeader>
          <CardContent className="prose prose-sm dark:prose-invert">
            <p>This application allows you to view profiles of terminated Roblox accounts.</p>
            <p>For terminated accounts:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Limited information may be available</li>
              <li>Profile data is based on last known information</li>
              <li>Some features like avatar, games, and badges may not be visible</li>
              <li>Account termination reasons are not provided by Roblox API</li>
            </ul>
            <p className="text-sm text-muted-foreground mt-4">
              Disclaimer: This application is not affiliated with Roblox Corporation.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
