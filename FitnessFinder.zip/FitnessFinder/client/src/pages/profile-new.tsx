import { useEffect, useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowLeft, AlertTriangle, History, Users, UserPlus, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import UserAvatar from "@/components/profile-viewer/user-avatar";
import UserInfo from "@/components/profile-viewer/user-info";
import UserStats from "@/components/profile-viewer/user-stats";
import UserDetails from "@/components/profile-viewer/user-details";
import { getUserStatus, getUserStats } from "@/lib/roblox-api";
import type { RobloxUser } from "@shared/schema";
import { ThemeToggle } from "@/components/theme-toggle";

function PreviousUsernames({ previousUsernames }: { previousUsernames: string[] }) {
  if (!previousUsernames || previousUsernames.length === 0) {
    return null;
  }

  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center">
          <History className="h-4 w-4 mr-2 text-primary" />
          Previous Usernames
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {previousUsernames.map((username, index) => (
            <Badge key={index} variant="outline">
              {username}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default function ProfilePage() {
  const [, params] = useRoute("/profile/:userId");
  const userId = params?.userId || "";
  
  // State for modals to display friends, followers, and following
  const [showFriendsDialog, setShowFriendsDialog] = useState(false);
  const [showFollowersDialog, setShowFollowersDialog] = useState(false);
  const [showFollowingDialog, setShowFollowingDialog] = useState(false);
  const [friendsList, setFriendsList] = useState<any[]>([]);
  const [followersList, setFollowersList] = useState<any[]>([]);
  const [followingList, setFollowingList] = useState<any[]>([]);
  const [isLoadingFriends, setIsLoadingFriends] = useState(false);
  const [isLoadingFollowers, setIsLoadingFollowers] = useState(false);
  const [isLoadingFollowing, setIsLoadingFollowing] = useState(false);
  
  // Fetch user data
  const { data: userData = {
    data: undefined,
    avatarUrl: null,
    isTerminated: false,
    previousUsernames: [],
    stats: {
      friends: 0,
      followers: 0,
      following: 0
    }
  }, isLoading: isUserLoading, error: userError } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });
  
  // Fetch user status
  const [status, setStatus] = useState("");
  const [isStatusLoading, setIsStatusLoading] = useState(false);
  
  // Fetch stats (friends, followers, following)
  const [localStats, setLocalStats] = useState({
    friends: "N/A",
    followers: "N/A",
    following: "N/A"
  });
  const [isStatsLoading, setIsStatsLoading] = useState(false);
  
  useEffect(() => {
    if (!userId) return;
    
    async function fetchAdditionalData() {
      try {
        // Fetch status
        setIsStatusLoading(true);
        try {
          const statusData = await getUserStatus(userId);
          setStatus(statusData.status || "");
        } catch (e) {
          console.error("Failed to fetch status", e);
        } finally {
          setIsStatusLoading(false);
        }
        
        // Fetch stats
        setIsStatsLoading(true);
        try {
          const statsData = await getUserStats(userId);
          setLocalStats(statsData);
        } catch (e) {
          console.error("Failed to fetch stats", e);
        } finally {
          setIsStatsLoading(false);
        }
      } catch (error: any) {
        console.error("Failed to load profile data", error);
      }
    }
    
    fetchAdditionalData();
  }, [userId]);
  
  if (!userId) {
    return (
      <div className="container max-w-5xl mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>User ID is required</AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link to="/">Go back to search</Link>
        </Button>
      </div>
    );
  }
  
  if (userError) {
    return (
      <div className="container max-w-5xl mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error loading profile</AlertTitle>
          <AlertDescription>
            {userError instanceof Error ? userError.message : "An unknown error occurred"}
          </AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link to="/">Go back to search</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <Button asChild variant="outline" className="mb-6">
        <Link to="/">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Search
        </Link>
      </Button>
      
      {isUserLoading || !userData ? (
        <ProfileSkeleton />
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="flex flex-col items-center md:items-start space-y-2">
              <UserAvatar 
                avatarUrl={userData.avatarUrl} 
                username={userData.data?.name || "Unknown"} 
                isTerminated={userData.isTerminated || false}
                size="xl"
              />
            </div>
            
            <div className="md:col-span-3 space-y-4">
              <UserInfo 
                displayName={userData.data?.displayName || userData.data?.name || "Unknown"} 
                username={userData.data?.name || "Unknown"}
                status={isStatusLoading ? "Loading status..." : status}
                description={userData.data?.description || ""}
                isTerminated={userData.isTerminated || false}
              />
              
              {userData.previousUsernames && userData.previousUsernames.length > 0 && (
                <PreviousUsernames previousUsernames={userData.previousUsernames} />
              )}
              
              <UserStats 
                friends={userData.stats?.friends !== undefined ? userData.stats.friends : localStats.friends}
                followers={userData.stats?.followers !== undefined ? userData.stats.followers : localStats.followers}
                following={userData.stats?.following !== undefined ? userData.stats.following : localStats.following}
                joinDate={userData.data?.created}
              />
            </div>
          </div>
          
          <UserDetails 
            userId={userId} 
            isTerminated={userData.isTerminated || false}
          />
        </div>
      )}
    </div>
  );
}

function ProfileSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex flex-col items-center md:items-start space-y-2">
          <Skeleton className="h-40 w-40 rounded-full" />
        </div>
        
        <div className="md:col-span-3 space-y-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
      
      <Skeleton className="h-60 w-full" />
    </div>
  );
}